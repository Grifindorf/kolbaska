//English
1. Install plugin "plg_jshopping_addon_resize_product_picture_v1.1.zip" through Extension Manager, then through the Plug-in Manager make it Enable.
2. Install the addon "JomShopping_addon_resize_product_picture_v1.1.zip" through the administrative panel component JoomShopping (Install / Update)
plg_jshopping_addon_resize_product_picture_v1.1.zip


//Deutch
1. Installieren plugin "plg_jshopping_addon_resize_product_picture_v1.1.zip" durch Erweiterungen: Installieren, dann durch die Plugins machen es zu Aktiviert.
2. Installieren Sie das Addon "JomShopping_addon_resize_product_picture_v1.1.zip" durch die Verwaltungs-Panel Komponente JoomShopping (Installieren & Update)